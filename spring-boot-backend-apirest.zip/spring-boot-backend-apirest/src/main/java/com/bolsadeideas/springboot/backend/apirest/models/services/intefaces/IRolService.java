package com.bolsadeideas.springboot.backend.apirest.models.services.intefaces;

import com.bolsadeideas.springboot.backend.apirest.models.entity.RolEntity;

public interface IRolService {
    public void sava(RolEntity rolEntity);
}
