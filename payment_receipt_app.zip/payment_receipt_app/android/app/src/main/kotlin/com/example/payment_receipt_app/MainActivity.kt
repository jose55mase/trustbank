package com.example.payment_receipt_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
