import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:path_provider/path_provider.dart';
import 'package:intl/intl.dart';
import '../models/payment_receipt.dart';

class PdfService {
  static Future<void> generateAndDownloadReceipt(PaymentReceipt receipt) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Header(
                level: 0,
                child: pw.Text(
                  'COMPROBANTE DE PAGO',
                  style: pw.TextStyle(
                    fontSize: 24,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
              pw.SizedBox(height: 20),
              pw.Container(
                padding: const pw.EdgeInsets.all(16),
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.grey),
                  borderRadius: pw.BorderRadius.circular(8),
                ),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    _buildInfoRow('ID de Transacción:', receipt.id),
                    _buildInfoRow('Beneficiario:', receipt.recipientName),
                    _buildInfoRow('Cuenta Destino:', receipt.recipientAccount),
                    _buildInfoRow('Monto:', '${receipt.currency} ${NumberFormat('#,##0.00').format(receipt.amount)}'),
                    _buildInfoRow('Fecha:', DateFormat('dd/MM/yyyy HH:mm').format(receipt.date)),
                    _buildInfoRow('Concepto:', receipt.concept),
                    _buildInfoRow('Referencia:', receipt.reference),
                    _buildInfoRow('Estado:', receipt.status),
                  ],
                ),
              ),
              pw.SizedBox(height: 30),
              pw.Text(
                'Este comprobante es válido como constancia de pago.',
                style: pw.TextStyle(
                  fontSize: 12,
                  fontStyle: pw.FontStyle.italic,
                ),
              ),
            ],
          );
        },
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
  }

  static pw.Widget _buildInfoRow(String label, String value) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 4),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.SizedBox(
            width: 120,
            child: pw.Text(
              label,
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
          ),
          pw.Expanded(
            child: pw.Text(value),
          ),
        ],
      ),
    );
  }
}